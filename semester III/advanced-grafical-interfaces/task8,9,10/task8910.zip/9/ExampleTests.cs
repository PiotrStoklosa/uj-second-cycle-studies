﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace _9
{
    [TestClass]
    public class ExampleTests
    {
        [TestMethod]
        public void Potęga_PositiveFlag_PositiveExponent_ReturnsPower()
        {
            var result = Program.Potęga(2, 3, 1);
            Assert.AreEqual(8.0, result);
        }

        [TestMethod]
        public void Potęga_PositiveFlag_NegativeExponent_ReturnsErrorMessage()
        {
            var result = Program.Potęga(2, -1, 1);
            Assert.AreEqual("wykładnik mniejszy od 0", result);
        }

        [TestMethod]
        public void Potęga_NonPositiveFlag_ReturnsErrorMessage()
        {
            var result = Program.Potęga(2, 3, 0);
            Assert.AreEqual("trzeci argument jest mniejszy od 0", result);
        }

        [TestMethod]
        public void ZapiszWTablicy_MultipliesElements_ReturnsNewArray()
        {
            var array = new List<int> { 1, 2, 3 };
            var result = Program.ZapiszWTablicy(array, 2);
            CollectionAssert.AreEqual(new List<int> { 2, 4, 6 }, result);
        }

        [TestMethod]
        public void PoleKola_PositiveRadius_ReturnsArea()
        {
            var result = Program.PoleKola(2);
            Assert.AreEqual(Math.PI * 4, result);
        }

        [TestMethod]
        public void PoleKola_NonPositiveRadius_ReturnsErrorMessage()
        {
            var result = Program.PoleKola(-1);
            Assert.AreEqual("promień musi być większy od 0", result);
        }

        [TestMethod]
        public void SumaCyfr_ValidThreeDigitNumber_DivisibleByThree_ReturnsMessage()
        {
            var result = Program.SumaCyfr(123);
            Assert.AreEqual("liczba podzielna przez 3", result);
        }

        [TestMethod]
        public void SumaCyfr_ValidThreeDigitNumber_NotDivisibleByThree_ReturnsMessage()
        {
            var result = Program.SumaCyfr(124);
            Assert.AreEqual("liczba nie jest podzielna przez 3", result);
        }

        [TestMethod]
        public void SumaCyfr_InvalidNumber_ReturnsErrorMessage()
        {
            var result = Program.SumaCyfr(99);
            Assert.AreEqual("podana liczba nie jest trzycyfrowa", result);
        }

        [TestMethod]
        public void ZamienElementy_ValidIndicesAndPositiveFlag_SwapsElements()
        {
            var array = new List<int> { 1, 2, 3 };
            var result = Program.ZamienElementy(array, 0, 2, 1) as List<int>;
            CollectionAssert.AreEqual(new List<int> { 3, 2, 1 }, result);
        }

        [TestMethod]
        public void ZamienElementy_InvalidIndices_ReturnsErrorMessage()
        {
            var array = new List<int> { 1, 2, 3 };
            var result = Program.ZamienElementy(array, -1, 2, 1);
            Assert.AreEqual("indeks spoza zakresu", result);
        }

        [TestMethod]
        public void ZamienElementy_NonPositiveFlag_ReturnsOriginalArray()
        {
            var array = new List<int> { 1, 2, 3 };
            var result = Program.ZamienElementy(array, 0, 2, 0) as List<int>;
            CollectionAssert.AreEqual(new List<int> { 1, 2, 3 }, result);
        }
    }

}