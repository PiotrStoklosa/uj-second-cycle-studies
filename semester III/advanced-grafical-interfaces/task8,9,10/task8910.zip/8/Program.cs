﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Program
{

    static void Main(string[] args)
    {
    }
    public static object Potęga(int baseValue, int exponent, int flag)
    {
        if (flag > 0)
        {
            if (exponent < 0)
            {
                return "wykładnik mniejszy od 0";
            }
            return Math.Pow(baseValue, exponent);
        }
        return "trzeci argument jest mniejszy od 0";
    }

    public static List<int> ZapiszWTablicy(List<int> array, int multiplier)
    {
        return array.Select(element => element * multiplier).ToList();
    }

    public static object PoleKola(double radius)
    {
        if (radius <= 0)
        {
            return "promień musi być większy od 0";
        }
        return Math.PI * Math.Pow(radius, 2);
    }

    public static string SumaCyfr(int number)
    {
        if (number >= 100 && number <= 999)
        {
            int sum = number.ToString().Sum(c => c - '0');
            return sum % 3 == 0 ? "liczba podzielna przez 3" : "liczba nie jest podzielna przez 3";
        }
        return "podana liczba nie jest trzycyfrowa";
    }

    public static object ZamienElementy(List<int> array, int index1, int index2, int flag)
    {
        if (flag > 0)
        {
            if (index1 < 0 || index1 >= array.Count || index2 < 0 || index2 >= array.Count)
            {
                return "indeks spoza zakresu";
            }
            int temp = array[index1];
            array[index1] = array[index2];
            array[index2] = temp;
        }
        return array;
    }
}
