﻿using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace _10
{
    [TestFixture]
    public class ExampleTests
    {
        [Test]
        public void Potęga_PositiveFlag_PositiveExponent_ReturnsPower()
        {
            var result = Program.Potęga(2, 3, 1);
            Assert.That(result, Is.EqualTo(8.0));
        }

        [Test]
        public void Potęga_PositiveFlag_NegativeExponent_ReturnsErrorMessage()
        {
            var result = Program.Potęga(2, -1, 1);
            Assert.That(result, Is.EqualTo("wykładnik mniejszy od 0"));
        }

        [Test]
        public void Potęga_NonPositiveFlag_ReturnsErrorMessage()
        {
            var result = Program.Potęga(2, 3, 0);
            Assert.That(result, Is.EqualTo("trzeci argument jest mniejszy od 0"));
        }

        [Test]
        public void ZapiszWTablicy_MultipliesElements_ReturnsNewArray()
        {
            var array = new List<int> { 1, 2, 3 };
            var result = Program.ZapiszWTablicy(array, 2);
            Assert.That(result, Is.EqualTo(new List<int> { 2, 4, 6 }));
        }

        [Test]
        public void PoleKola_PositiveRadius_ReturnsArea()
        {
            var result = Program.PoleKola(2);
            Assert.That(result, Is.EqualTo(Math.PI * 4));
        }

        [Test]
        public void PoleKola_NonPositiveRadius_ReturnsErrorMessage()
        {
            var result = Program.PoleKola(-1);
            Assert.That(result, Is.EqualTo("promień musi być większy od 0"));
        }

        [Test]
        public void SumaCyfr_ValidThreeDigitNumber_DivisibleByThree_ReturnsMessage()
        {
            var result = Program.SumaCyfr(123);
            Assert.That(result, Is.EqualTo("liczba podzielna przez 3"));
        }

        [Test]
        public void SumaCyfr_ValidThreeDigitNumber_NotDivisibleByThree_ReturnsMessage()
        {
            var result = Program.SumaCyfr(124);
            Assert.That(result, Is.EqualTo("liczba nie jest podzielna przez 3"));
        }

        [Test]
        public void SumaCyfr_InvalidNumber_ReturnsErrorMessage()
        {
            var result = Program.SumaCyfr(99);
            Assert.That(result, Is.EqualTo("podana liczba nie jest trzycyfrowa"));
        }

        [Test]
        public void ZamienElementy_ValidIndicesAndPositiveFlag_SwapsElements()
        {
            var array = new List<int> { 1, 2, 3 };
            var result = Program.ZamienElementy(array, 0, 2, 1) as List<int>;
            Assert.That(result, Is.EqualTo(new List<int> { 3, 2, 1 }));
        }

        [Test]
        public void ZamienElementy_InvalidIndices_ReturnsErrorMessage()
        {
            var array = new List<int> { 1, 2, 3 };
            var result = Program.ZamienElementy(array, -1, 2, 1);
            Assert.That(result, Is.EqualTo("indeks spoza zakresu"));
        }

        [Test]
        public void ZamienElementy_NonPositiveFlag_ReturnsOriginalArray()
        {
            var array = new List<int> { 1, 2, 3 };
            var result = Program.ZamienElementy(array, 0, 2, 0) as List<int>;
            Assert.That(result, Is.EqualTo(new List<int> { 1, 2, 3 }));
        }
    }
}
